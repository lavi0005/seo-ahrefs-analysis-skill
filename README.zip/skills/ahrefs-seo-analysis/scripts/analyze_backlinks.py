#!/usr/bin/env python3
"""Backlink profile health from an Ahrefs 'Backlinks' or 'Referring domains' export."""
import argparse
import os
import re
import pandas as pd
from ahrefs_io import load_export, find_col, to_num, md_table


def classify_anchor(anchor, brands):
    a = str(anchor).strip().lower()
    if not a or a == "nan":
        return "empty/image"
    if re.match(r"^(https?://|www\.)", a) or re.search(r"\.[a-z]{2,}(/|$)", a):
        return "url"
    if any(b in a for b in brands):
        return "branded"
    if a in {"click here", "here", "read more", "visit", "website", "this", "link", "source", "more", "learn more", "check it out"}:
        return "generic"
    return "keyword/other"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("csv")
    ap.add_argument("--brand", default="", help="Brand term(s), comma separated")
    ap.add_argument("--out", default="out/backlinks")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    df = load_export(a.csv)
    ref_url = find_col(df, "Referring page URL")
    dom = find_col(df, "Referring domain", "Domain", warn=False)
    dr = find_col(df, "Domain rating", "DR")
    anchor = find_col(df, "Anchor")
    nofollow = find_col(df, "Nofollow")
    dofollow = find_col(df, "Dofollow", warn=False)
    target = find_col(df, "Target URL")

    if dr:
        df[dr] = to_num(df[dr])
    if not dom and ref_url:
        df["_domain"] = df[ref_url].astype(str).str.extract(r"https?://([^/]+)")[0].str.replace("www.", "", regex=False)
        dom = "_domain"
    if not dom:
        raise SystemExit("Need a referring domain or referring page URL column.")

    lines = ["# Backlink profile\n", f"Rows: {len(df):,} | Unique referring domains: {df[dom].nunique():,}\n"]

    # DR mix (per domain)
    if dr:
        per_dom = df.groupby(dom)[dr].max().reset_index()
        bins = pd.cut(per_dom[dr], [-1, 9, 29, 49, 69, 100], labels=["0-9", "10-29", "30-49", "50-69", "70-100"])
        mix = bins.value_counts().reindex(["0-9", "10-29", "30-49", "50-69", "70-100"]).reset_index()
        mix.columns = ["DR band", "Referring domains"]
        mix["Share %"] = (mix["Referring domains"] / mix["Referring domains"].sum() * 100).round(0)
        lines.append("\n## Referring domain quality (DR)\n" + md_table(mix))

    # Dofollow ratio
    nf = None
    if nofollow:
        nf = df[nofollow].astype(str).str.lower().isin(["true", "1", "yes"])
    elif dofollow:
        nf = ~df[dofollow].astype(str).str.lower().isin(["true", "1", "yes"])
    if nf is not None:
        dof = (1 - nf.mean()) * 100
        note = " - unusual, review" if dof > 97 or dof < 30 else ""
        lines.append(f"\n## Dofollow ratio\n{dof:.0f}% dofollow{note}\n")

    # Concentration
    counts = df.groupby(dom).size().sort_values(ascending=False).reset_index()
    counts.columns = ["Domain", "Links"]
    top5 = counts["Links"].head(5).sum() / counts["Links"].sum() * 100
    lines.append(f"\n## Link concentration\nTop 5 domains supply {top5:.0f}% of links (possible sitewide/footer links)\n\n" + md_table(counts, 10))

    # Anchors
    if anchor:
        brands = [b.strip().lower() for b in a.brand.split(",") if b.strip()]
        df["_anchor_type"] = df[anchor].apply(lambda x: classify_anchor(x, brands))
        amix = df["_anchor_type"].value_counts().reset_index()
        amix.columns = ["Anchor type", "Links"]
        amix["Share %"] = (amix["Links"] / amix["Links"].sum() * 100).round(0)
        kw_share = amix.loc[amix["Anchor type"] == "keyword/other", "Share %"].sum()
        warn = " - high share of keyword anchors; check for over-optimization" if kw_share > 40 else ""
        lines.append(f"\n## Anchor text mix\n" + md_table(amix) + warn + "\n")
        if not brands:
            lines.append("_Tip: pass --brand to separate branded anchors._\n")
        top_anchors = df[anchor].astype(str).value_counts().head(15).reset_index()
        top_anchors.columns = ["Anchor", "Links"]
        lines.append("\n### Top anchors\n" + md_table(top_anchors))

    # Risky candidates (review only)
    if dr:
        risky = df[df[dr] <= 5]
        if anchor:
            risky = risky[risky["_anchor_type"].isin(["keyword/other"])]
        cols = [c for c in (ref_url, dom, dr, anchor, target) if c and c in risky.columns]
        risky[cols].to_csv(f"{a.out}/review_candidates.csv", index=False)
        lines.append(f"\n## Review candidates (DR <= 5 with keyword-style anchors)\n{len(risky)} links. Review manually; do NOT bulk-disavow.\n\n" + md_table(risky[cols]))

    report = "\n".join(lines)
    with open(f"{a.out}/backlink_report.md", "w") as f:
        f.write(report)
    print(report)
    print(f"\nSaved to {a.out}/")


if __name__ == "__main__":
    main()
