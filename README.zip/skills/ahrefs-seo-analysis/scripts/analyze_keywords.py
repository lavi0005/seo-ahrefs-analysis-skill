#!/usr/bin/env python3
"""Keyword opportunity analysis from an Ahrefs 'Organic keywords' export."""
import argparse
import os
import pandas as pd
from ahrefs_io import load_export, find_col, to_num, md_table


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("csv")
    ap.add_argument("--dr", type=float, default=30, help="Target domain DR; sets KD ceiling for quick wins")
    ap.add_argument("--min-volume", type=int, default=50)
    ap.add_argument("--brand", default="", help="Brand term(s), comma separated, to split branded traffic")
    ap.add_argument("--out", default="out/keywords")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    df = load_export(a.csv)
    kw = find_col(df, "Keyword", required=True)
    vol = find_col(df, "Volume")
    kd = find_col(df, "KD", "Keyword difficulty")
    pos = find_col(df, "Current position", "Position", required=True)
    prev = find_col(df, "Previous position")
    url = find_col(df, "Current URL", "URL")
    traf = find_col(df, "Current organic traffic", "Traffic", "Organic traffic")
    intent = find_col(df, "Intent")

    for c in (vol, kd, pos, prev, traf):
        if c:
            df[c] = to_num(df[c])

    lines = [f"# Keyword analysis\n", f"Rows: {len(df):,} keywords\n"]

    # Branded split
    if a.brand and traf:
        terms = [t.strip().lower() for t in a.brand.split(",") if t.strip()]
        mask = df[kw].astype(str).str.lower().apply(lambda k: any(t in k for t in terms))
        total = df[traf].sum()
        b = df.loc[mask, traf].sum()
        lines.append(f"\n## Branded vs non-branded\nBranded est. traffic: {b:,.0f} of {total:,.0f} ({(b/total*100 if total else 0):.0f}%)\n")
        df = df.assign(_branded=mask)
        nb = df[~mask]
    else:
        nb = df

    # Position buckets
    buckets = pd.cut(df[pos], [0, 3, 10, 20, 50, 1000], labels=["1-3", "4-10", "11-20", "21-50", "51+"])
    dist = buckets.value_counts().reindex(["1-3", "4-10", "11-20", "21-50", "51+"]).reset_index()
    dist.columns = ["Position bucket", "Keywords"]
    lines.append("\n## Ranking distribution\n" + md_table(dist))

    cols = [c for c in (kw, pos, vol, kd, traf, url, intent) if c]

    # Striking distance
    sd = nb[(nb[pos] >= 4) & (nb[pos] <= 20)]
    if vol:
        sd = sd[sd[vol] >= a.min_volume].sort_values(vol, ascending=False)
    sd[cols].to_csv(f"{a.out}/striking_distance.csv", index=False)
    lines.append(f"\n## Striking distance (positions 4-20, volume >= {a.min_volume})\n{len(sd)} keywords\n\n" + md_table(sd[cols]))

    # Quick wins: easy keywords ranking beyond 20
    if kd and vol:
        ceiling = a.dr + 10
        qw = nb[(nb[pos] > 20) & (nb[kd] <= ceiling) & (nb[vol] >= a.min_volume)].sort_values(vol, ascending=False)
        qw[cols].to_csv(f"{a.out}/quick_wins.csv", index=False)
        lines.append(f"\n## Quick wins (position > 20, KD <= {ceiling:.0f})\n{len(qw)} keywords\n\n" + md_table(qw[cols]))

    # Losers
    if prev:
        d = df.assign(_change=df[pos] - df[prev])  # positive = dropped
        lose = d[(d["_change"] >= 5) | ((d[prev] <= 10) & (d[pos] > 10))]
        if traf:
            lose = lose.sort_values(traf, ascending=False)
        lose_cols = cols + [prev, "_change"]
        lose[lose_cols].to_csv(f"{a.out}/losers.csv", index=False)
        lines.append(f"\n## Losers (dropped 5+ or fell out of top 10)\n{len(lose)} keywords\n\n" + md_table(lose[lose_cols]))

    # Top pages and concentration
    if url and traf:
        pages = df.groupby(url).agg(keywords=(kw, "count"), est_traffic=(traf, "sum")).sort_values("est_traffic", ascending=False).reset_index()
        pages.to_csv(f"{a.out}/top_pages.csv", index=False)
        total = pages["est_traffic"].sum()
        top3 = pages["est_traffic"].head(3).sum()
        share = top3 / total * 100 if total else 0
        flag = " - concentration risk" if share > 60 else ""
        lines.append(f"\n## Top pages\nTop 3 pages hold {share:.0f}% of estimated traffic{flag}\n\n" + md_table(pages))

    # Intent mix
    if intent:
        mix = df[intent].astype(str).value_counts().head(8).reset_index()
        mix.columns = ["Intent", "Keywords"]
        lines.append("\n## Intent mix\n" + md_table(mix))

    report = "\n".join(lines)
    with open(f"{a.out}/keyword_report.md", "w") as f:
        f.write(report)
    print(report)
    print(f"\nSaved to {a.out}/")


if __name__ == "__main__":
    main()
