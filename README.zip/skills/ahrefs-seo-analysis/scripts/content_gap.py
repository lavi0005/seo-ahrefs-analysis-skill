#!/usr/bin/env python3
"""Content gap analysis from an Ahrefs Content Gap export."""
import argparse
import os
import numpy as np
import pandas as pd
from ahrefs_io import load_export, find_col, norm, to_num, md_table


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("csv")
    ap.add_argument("--target", required=True, help="Target domain, as it appears in the column header")
    ap.add_argument("--min-competitors", type=int, default=2)
    ap.add_argument("--min-volume", type=int, default=50)
    ap.add_argument("--max-kd", type=float, default=100)
    ap.add_argument("--out", default="out/gap")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    df = load_export(a.csv)
    kw = find_col(df, "Keyword", required=True)
    vol = find_col(df, "Volume", required=True)
    kd = find_col(df, "KD", "Keyword difficulty")
    df[vol] = to_num(df[vol])
    if kd:
        df[kd] = to_num(df[kd])

    t = norm(a.target)
    skip = ("url", "traffic", "intent", "cpc", "volume", "keyword", "kd", "difficulty", "parent", "sf")
    site_cols = [c for c in df.columns if c not in (kw, vol, kd)
                 and not any(w in c.lower() for w in skip) and to_num(df[c]).notna().mean() > 0]
    target_cols = [c for c in site_cols if t in norm(c)]
    if not target_cols:
        raise SystemExit(f"No column matches target '{a.target}'. Columns: {list(df.columns)}")
    tcol = target_cols[0]
    comp_cols = [c for c in site_cols if c != tcol]

    pos = df[comp_cols + [tcol]].apply(to_num)
    df["_competitors"] = pos[comp_cols].notna().sum(axis=1)
    df["_best_comp_pos"] = pos[comp_cols].min(axis=1)
    gap = df[pos[tcol].isna() | (pos[tcol] > 20)]
    gap = gap[(gap["_competitors"] >= a.min_competitors) & (gap[vol] >= a.min_volume)]
    if kd:
        gap = gap[gap[kd].fillna(0) <= a.max_kd]
        feas = 1 / (1 + gap[kd].fillna(30) / 20)
    else:
        feas = 1
    gap = gap.assign(score=(gap[vol] * feas * gap["_competitors"]).round(0)).sort_values("score", ascending=False)

    out_cols = [kw, vol] + ([kd] if kd else []) + ["_competitors", "_best_comp_pos", "score"]
    pretty = gap[out_cols].rename(columns={"_competitors": "competitors ranking", "_best_comp_pos": "best competitor pos"})
    pretty.to_csv(f"{a.out}/content_gap.csv", index=False)

    # crude cluster hint: first two words
    gap = gap.assign(cluster=gap[kw].astype(str).str.split().str[:2].str.join(" "))
    clusters = gap.groupby("cluster").agg(keywords=(kw, "count"), total_volume=(vol, "sum"), score=("score", "sum")) \
        .sort_values("score", ascending=False).reset_index()

    lines = [
        "# Content gap\n",
        f"Target: {tcol} | Competitors detected: {len(comp_cols)} | Gap keywords: {len(gap):,}\n",
        f"\n## Top gap keywords (ranked by 2+ competitors, target absent or > 20)\n" + md_table(pretty),
        "\n## Cluster hints (first two words; refine manually)\n" + md_table(clusters),
    ]
    report = "\n".join(lines)
    with open(f"{a.out}/content_gap_report.md", "w") as f:
        f.write(report)
    print(report)
    print(f"\nSaved to {a.out}/")


if __name__ == "__main__":
    main()
