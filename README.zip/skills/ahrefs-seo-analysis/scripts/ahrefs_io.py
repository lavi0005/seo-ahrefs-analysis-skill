"""Shared helpers for reading Ahrefs CSV exports."""
import re
import sys
import pandas as pd


def load_export(path):
    """Load an Ahrefs export. Handles UTF-16/UTF-8 and tab/comma separators."""
    last_err = None
    for enc in ("utf-16", "utf-8-sig", "utf-8", "latin-1"):
        for sep in ("\t", ","):
            try:
                df = pd.read_csv(path, encoding=enc, sep=sep, low_memory=False)
                if df.shape[1] > 1:
                    df.columns = [str(c).strip() for c in df.columns]
                    return df
            except Exception as e:  # try next combination
                last_err = e
    sys.exit(f"Could not parse {path}: {last_err}")


def norm(s):
    return re.sub(r"[^a-z0-9]", "", str(s).lower())


def find_col(df, *aliases, required=False, label=None, loose=False, warn=True):
    """Return the first column whose normalised name equals an alias (exact by default;
    loose=True also allows substring matches)."""
    lookup = {norm(c): c for c in df.columns}
    for a in aliases:
        if norm(a) in lookup:
            return lookup[norm(a)]
    if loose:
        for a in aliases:
            for k, v in lookup.items():
                if norm(a) in k:
                    return v
    if required:
        sys.exit(f"Missing required column ({label or aliases[0]}). Found: {list(df.columns)}")
    if warn:
        print(f"[warn] column not found: {label or aliases[0]} - related checks skipped")
    return None


def to_num(series):
    return pd.to_numeric(series.astype(str).str.replace(",", "").str.strip(), errors="coerce")


def md_table(df, max_rows=15):
    if df is None or df.empty:
        return "_none found_\n"
    return df.head(max_rows).to_markdown(index=False) + "\n"
