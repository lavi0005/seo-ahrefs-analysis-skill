# Analysis modules and judgment rules

## 1. Keyword opportunities

- **Striking distance**: positions 4-20 with meaningful volume. Typical fixes: expand on-page coverage, improve title/H1 match, add internal links, refresh content. Highest ROI per hour of work.
- **Quick wins**: KD at or below a DR-based ceiling, volume above a floor, currently unranked or beyond position 20. Map each to an existing page or a new page.
- **Losers**: position drop of 5 or more, or lost top-10. Check SERP-feature changes, competitor content refreshes, lost backlinks, cannibalization, and technical regressions before prescribing a fix.
- **Traffic concentration**: if the top 3 pages drive over about 60 percent of estimated traffic, flag the risk and recommend broadening topical coverage.
- **Branded vs non-branded**: split them. Growth is judged on non-branded.

## 2. Backlink health

- **DR mix**: healthy profiles are not all high DR; look for a natural spread.
- **Dofollow ratio**: extremes (nearly 100 percent or under 30 percent) deserve a look.
- **Anchor text**: expect mostly branded, URL, and generic anchors. A high share of exact-match commercial anchors is an over-optimization signal.
- **Referring domain concentration**: many links from few domains (sitewide/footer links) inflate link counts without adding value. Judge by referring domains, not raw links.
- **Risky candidates**: very low DR plus off-topic plus unnatural anchors plus link-network patterns. Flag for review; do not auto-disavow.
- **Link velocity**: sudden spikes or drops need an explanation (campaign, lost links, migration).

## 3. Content gap

- Prioritize keywords that **2 or more competitors rank for and the target does not**. Single-competitor gaps are lower confidence.
- Score = volume weighted by feasibility (lower KD better) and by number of competitors ranking.
- Group gaps into topic clusters before recommending pages; one page per cluster, not per keyword.
- Drop gaps with intent mismatch (for example, job-seeker or free-tool queries for a paid service).

## 4. Technical (Site Audit)

Prioritize by scale and severity: indexability issues (noindex, canonical errors, 4xx/5xx in sitemaps), redirect chains, duplicate titles/meta, missing H1, slow pages, orphan pages, broken internal links. Report issue count and sample URLs; fix in order of traffic at risk.

## 5. Prioritization

Score each action: **Impact** (estimated traffic or revenue gain) x **Confidence** (how solid the data is) divided by **Effort**. Present the top 5, then the rest as a backlog.
