# Ahrefs exports: what to pull

| Goal | Ahrefs report | Notes |
|---|---|---|
| Keyword opportunities | Site Explorer > Organic search > Organic keywords | Set country; export all columns. Enable a comparison date so "Previous position" is included. |
| Backlinks | Site Explorer > Backlinks | Mode: domain or subdomains; export live links. |
| Referring domains | Site Explorer > Referring domains | Gives DR per domain, useful for quality mix. |
| Lost links | Backlinks > Lost | Needed to explain DR/traffic drops. |
| Top pages | Site Explorer > Top pages | Traffic concentration and cannibalization hints. |
| Content gap | Site Explorer > Content gap | Target + up to 10 competitors. |
| Technical | Site Audit > Issues | Export issue list with affected URLs. |

## Common column names the scripts recognise

Matching is case-insensitive and tolerant of small naming changes.

- Keywords: `Keyword`, `Volume`, `KD`, `CPC`, `Current position`, `Previous position`, `Current URL`, `Current organic traffic`, `Intent`
- Backlinks: `Referring page URL`, `Domain rating`, `UR`, `Target URL`, `Anchor`, `Nofollow`, `Type`
- Referring domains: `Domain`, `Domain rating`, `Dofollow linked domains`, `Links to target`
- Content gap: `Keyword`, `Volume`, `KD`, then one position column per site (header contains the domain)

If a column is missing, the script prints which one and continues with the checks it can still run.
