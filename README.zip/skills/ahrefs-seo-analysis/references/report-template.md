# SEO Analysis Report: {domain}

**Market:** {country} | **Export date:** {date} | **Competitors:** {list}
**Data used:** {exports} | **Data missing:** {gaps}

## 1. Executive summary
3-5 sentences: current position, biggest opportunity, biggest risk.

## 2. Top 5 actions
| # | Action | Evidence | Impact | Effort | Owner |
|---|---|---|---|---|---|

## 3. Keyword opportunities
- Striking-distance table (top 15)
- Quick wins (top 15)
- Losers and likely causes

## 4. Backlink profile
- DR distribution, dofollow ratio, top referring domains
- Anchor text mix and any over-optimization flags
- Risky link candidates (review, do not auto-disavow)

## 5. Content gap vs competitors
- Clustered opportunities with suggested page per cluster

## 6. Technical findings (if Site Audit provided)

## 7. 30/60/90-day plan

## 8. Caveats
Estimated metrics, partial data, market match, recommended cross-checks (Google Search Console).
